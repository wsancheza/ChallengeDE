#config file containing credentials for RDS MySQL instance
db_username = "wsaglbnt"
db_password = "MnTsEg2022"
db_name = "WSAExampleDB"
